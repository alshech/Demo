=======================================================
KEYLOGGER SIMULATOR - EDUCATIONAL PURPOSES ONLY
=======================================================

This application simulates keylogging behavior in a controlled environment
for security education and testing. It does NOT capture actual keystrokes
and does NOT send any real data over the network.

HOW TO USE:
-----------
1. Run the KeyloggerConsoleSimulator executable
2. Use the interactive commands to start/stop the simulation
3. Type '?' for a list of available commands

IMPORTANT SECURITY NOTICE:
-------------------------
- This software is designed for EDUCATIONAL PURPOSES ONLY
- No real keystrokes are captured or exfiltrated
- All network operations are simulated
- Use responsibly and ethically
