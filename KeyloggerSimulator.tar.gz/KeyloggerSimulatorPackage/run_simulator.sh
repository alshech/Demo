#!/bin/bash
echo "Starting Keylogger Simulator (Educational Demo)"
./KeyloggerConsoleSimulator
